/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mydsawork;

/**
 *
 * @author s4402831
 */
public class workingWithStrings {
    public static void main(String[] args) {
        String firstName = "Mike";
        String lastName = "Child";

        String fullName = firstName + " " + lastName;
        System.out.println(fullName);

        String formalName = lastName + ", " + firstName;
        System.out.println(formalName);
   
    }
}
